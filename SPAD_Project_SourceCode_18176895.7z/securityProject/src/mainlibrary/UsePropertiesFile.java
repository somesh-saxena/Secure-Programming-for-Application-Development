package mainlibrary;

/**
 *
 * @author Kaleemuddin
 */
import java.io.FileInputStream;
import java.util.Arrays;
import java.util.Base64;
import java.util.Properties;
import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

//import org.apache.commons.codec.binary.Base64;

public class UsePropertiesFile {
	Properties prop = new Properties();
	
	public String getPort()
	{
		String port = "";
		try {
			prop.load(new FileInputStream("C:\\Users\\IEUser\\Documents\\NetBeansProjects\\securityProject\\securityProject\\data.properties"));
			port = prop.getProperty("port");
		} catch (Exception e) {
			// TODO Auto-generated catch block
		}
		return port;
	}
	
	public String getUserName()
	{
		String UserName = "";
                String decrypt = "";
                String key = "";
                String dkey = "";
                String iv = "";
                String div = "";
		try {
			System.out.println("Reading Properties File.........");
			prop.load(new FileInputStream("C:\\Users\\IEUser\\Documents\\NetBeansProjects\\securityProject\\securityProject\\data.properties"));
			System.out.println("Connected to Properties File.........");
			UserName = prop.getProperty("username");
                        key = prop.getProperty("key");
                        dkey = setBase(key);
                        
                        iv = prop.getProperty("iv");
                        div = setBase(iv);
                        
                        decrypt = decrypt(dkey, div, UserName);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			System.out.println(e.getMessage());
		}
		return decrypt;
	}
	
	public String getPassword()
	{
		String Password = "";
                String decrypt = "";
                String key = "";
                String dkey = "";
                String iv = "";
                String div = "";
		try {
			prop.load(new FileInputStream("C:\\Users\\IEUser\\Documents\\NetBeansProjects\\securityProject\\securityProject\\data.properties"));
			Password = prop.getProperty("password");
                        key = prop.getProperty("key");
                        dkey = setBase(key);
                        
                        iv = prop.getProperty("iv");
                        div = setBase(iv);
                        //System.out.println("########Final#####"+key+dkey+iv+"%%%%%%%%%%"+div+"%%%%");
                        decrypt = decrypt(dkey, div, Password);
                        
		} catch (Exception e) {
			// TODO Auto-generated catch block
			System.out.println(e.getMessage());
		}
		return decrypt;
	}
        
        public static String encrypt(String key, String initVector, String value) {
        try {
            IvParameterSpec iv = new IvParameterSpec(initVector.getBytes("UTF-8"));
            SecretKeySpec skeySpec = new SecretKeySpec(key.getBytes("UTF-8"), "AES");

            Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5PADDING");
            cipher.init(Cipher.ENCRYPT_MODE, skeySpec, iv);

            byte[] encrypted = cipher.doFinal(value.getBytes());
            System.out.println("encrypted string: "
                    + Base64.getEncoder().encodeToString(encrypted));

            return Base64.getEncoder().encodeToString(encrypted);
        } catch (Exception ex) {
            ex.printStackTrace();
        }

        return null;
    }

    public static String decrypt(String key, String initVector, String encrypted) {
        try {
            IvParameterSpec iv = new IvParameterSpec(initVector.getBytes("UTF-8"));
            SecretKeySpec skeySpec = new SecretKeySpec(key.getBytes("UTF-8"), "AES");

            Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5PADDING");
            cipher.init(Cipher.DECRYPT_MODE, skeySpec, iv);

            //byte[] original = cipher.doFinal(Base64.decodeBase64(encrypted));
            
            byte[] original = cipher.doFinal(Base64.getDecoder().decode(encrypted));

            System.out.println("****new String(original)****"+new String(original));
            return new String(original);
        } catch (Exception ex) {
            ex.printStackTrace();
        }

        return null;
    }
    
    public static String getBase(String key)
    {
        Base64.Encoder encoder = Base64.getMimeEncoder();
        String eStr = encoder.encodeToString(key.getBytes());  
        System.out.println("Encoded MIME message: "+eStr);
        
        return eStr;
    }
    
    public static String setBase(String key)
    {
        Base64.Decoder decoder = Base64.getMimeDecoder();
        String dStr = new String(decoder.decode(key));  
        System.out.println("Decoded message: "+dStr);   
        
        return dStr;
    }
}