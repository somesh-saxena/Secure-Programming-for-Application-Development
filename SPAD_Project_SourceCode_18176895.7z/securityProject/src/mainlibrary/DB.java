/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mainlibrary;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

/**
 *
 * @author bikash
 */
public class DB {
    
     static UsePropertiesFile up = new UsePropertiesFile();
    static final String userdb = up.getUserName();
    static final String passdb = up.getPassword();
    static final String portdb = up.getPort();

    
    
    public static String user = "root";
    public static String connection = "jdbc:mysql://localhost:3306/library";
    
    public static Connection getConnection() {
        Connection con = null;
        try {
            System.out.println("*u,p,p*"+userdb+"jhbjbk%%"+passdb+"***"+portdb);
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:"+portdb+"/library", userdb, passdb);
            System.out.println("*Connected*");
            //con = DriverManager.getConnection(connection, yahan pe daal de variables. Its done. Thanks :));
        } catch (Exception e) {
            System.out.println(e);
        }
        return con;
    }

}